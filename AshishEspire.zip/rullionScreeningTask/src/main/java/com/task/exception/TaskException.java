package com.task.exception;

public class TaskException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2014406547821577913L;

	public TaskException(String error) {
		super(error);
	}
	
}
