package com.task.implementor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.task.exception.TaskException;

public class TaskImplementor {

	public String tasksExecution(List<String> taskList, List<String> dependencyList) {
		List<String> tempExecution = new LinkedList<>();
		List<String> fullyExceuted = new LinkedList<>();
		List<String> resultList = new LinkedList<>();
		Map<String, List<String>> task_dependencyMap = new HashMap<>();

		dependencyMapping(taskList, dependencyList, task_dependencyMap);

		taskList.forEach(task -> {
			try {
				if (!fullyExceuted.contains(task)) {
					findtask(task, task_dependencyMap, tempExecution, fullyExceuted, resultList);
				}
			} catch (TaskException ce) {
				throw ce;
			}
		});

		return resultList.toString();
	}

	// Find all non executed task
	// executed
	public void findtask(String task, Map<String, List<String>> task_dependencyMap, List<String> tempExecution,
			List<String> fullyExceuted, List<String> resultList) {
		// Throw an error if cyclic dependency found
		if (hasCycle(task, tempExecution)) {
			throw new TaskException("Error - this is a cyclic dependency");
		}

		if (!fullyExceuted.contains(task)) {
			tempExecution.add(task);

			if (!task_dependencyMap.get(task).isEmpty()) {
				task_dependencyMap.get(task).forEach(t -> {
					findtask(t, task_dependencyMap, tempExecution, fullyExceuted, resultList);
				});
			}
			// Add complete executed, remove temp execution, and add to resultList
			fullyExceuted.add(task);
			tempExecution.remove(task);
			resultList.add(task);
		}
	}

	public void dependencyMapping(List<String> taskList, List<String> dependencyList,
			Map<String, List<String>> task_dependencyMap) {
		taskList.forEach(task -> {
			task_dependencyMap.put(task, new ArrayList<String>());
		});

		dependencyList.forEach(dependency -> {
			task_dependencyMap.get(dependency.split("=>")[0]).add(dependency.split("=>")[1]);
		});
	}

	private boolean hasCycle(String task, List<String> tempExecution) {
		if (tempExecution.contains(task))
			return true;
		else
			return false;

	}

}
