package com.task;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.task.exception.TaskException;
import com.task.implementor.TaskImplementor;

public class TaskService {

	public static void main(String[] args) {

		try {
			List<String> taskList = new ArrayList<>();
			List<String> dependencyList = new ArrayList<>();
			// Enter Tasks and Dependencies
			inputTaskandDependency(taskList, dependencyList);
			TaskImplementor ti = new TaskImplementor();
			
			// Print all dependencies
			String result = ti.tasksExecution(taskList, dependencyList);

			System.out.println("Result: " + result);
		} catch (TaskException e) {
				System.out.println("Result: " + e.getMessage());

		}catch (Exception e) {
				e.printStackTrace();
		}

	}
	
	public static void inputTaskandDependency(List<String> taskList, List<String> dependencyList) {
		try (Scanner sc = new Scanner(System.in)) {
			int taskCount, dependencyCount;

			System.out.println("Enter total number of count for task to add : ");
			taskCount = sc.nextInt();

			for (int i = 0; i < taskCount; i++) {
				List<String> list = new ArrayList<String>();
				System.out.println("Enter task " + (i + 1) + " : ");
				list.add(sc.next());
				taskList.addAll(list);
			}

			System.out.println("Enter total number of count for dependencies to add : ");
			dependencyCount = sc.nextInt();
			for (int i = 0; i < dependencyCount; i++) {
				List<String> list = new ArrayList<String>();
				System.out.println("Enter dependencies for  " + (i + 1) + " like (element1 => element2): ");
				list.add(sc.next());
				dependencyList.addAll(list);
			}
			System.out.println("task added : " + taskList);
			System.out.println("dependency list added : " + dependencyList);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
