package rullionScreeningTask;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Collections;
import org.junit.Before;
import org.junit.Test;
import com.task.exception.TaskException;
import com.task.implementor.TaskImplementor;

public class TaskTest {

  public TaskTest() {}

  TaskImplementor timpl;

  @Before
  public void setUp() {
    timpl = new TaskImplementor();
  }

  @Test
  public void Test1() {
    String str =
        timpl.tasksExecution(Collections.<String>emptyList(), Collections.<String>emptyList());
    assertEquals("[]", str);
  }

  @Test
  public void Test2() {
    String str = timpl.tasksExecution(Arrays.asList("a", "b"), Collections.<String>emptyList());
    assertEquals("[a, b]", str);
  }

  @Test
  public void Test3() {
    String str = timpl.tasksExecution(Arrays.asList("a", "b"), Arrays.asList("a=>b"));
    assertEquals("[b, a]", str);
  }

  @Test
  public void Test4() {
    String str =
        timpl.tasksExecution(Arrays.asList("a", "b", "c", "d"), Arrays.asList("a=>b", "c=>d"));
    assertEquals("[b, a, d, c]", str);
  }

  @Test
  public void Test5() {
    String str =
        timpl.tasksExecution(Arrays.asList("a", "b", "c"), Arrays.asList("a=>b", "b=>c"));
    assertEquals("[c, b, a]", str);
  }

  @Test(expected = TaskException.class)
  public void Test6() {
    timpl.tasksExecution(Arrays.asList("a", "b", "c", "d"),
        Arrays.asList("a=>b", "b=>c", "c=>a"));
  }

}
